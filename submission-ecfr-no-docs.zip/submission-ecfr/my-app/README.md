Setup

1) Install latest version of Node JS - https://nodejs.org/en/download
2) Run `npm i` to install all initial dependencies
3) Install angular CLI - `npm install @angular/cli`
4) Install json-server `npm install -g json-server`  
5) Open a new terminal and cd into `my-app/src`  
6) In the terminal from step 5 run ` json-server --watch agencies-db.json` This launches the database
7) In the first terminal run ` npm run start` this should start the server
8) Go to `localhost:4200` or whatever is provided in the `npm run start` console


Additional details

1) In `external` directory there is a wordcount utility (Claude generated) and the local set of all titles within `documents`  
2) The search API uses the main eCFR to offload queries instead of making our own given this was a tightly timeboxed assessment.
