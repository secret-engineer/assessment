import { readFile, readFileSync } from 'fs';
import { promisify } from 'util';
import { resolve } from 'path';
import {DOMParser, onErrorStopParsing} from '@xmldom/xmldom';

const readFileAsync = promisify(readFile);

interface WordCountOptions {
  includeAttributes?: boolean;
  excludeElements?: string[];
  caseSensitive?: boolean;
  countNumbers?: boolean;
}

interface WordCountResult {
  totalWords: number;
  uniqueWords: number;
  wordFrequency: Map<string, number>;
  elementWordCounts: Map<string, number>;
  filePath?: string;
}

class XMLWordCounter {
  private options: Required<WordCountOptions>;

  constructor(options: WordCountOptions = {}) {
    this.options = {
      includeAttributes: options.includeAttributes ?? false,
      excludeElements: options.excludeElements ?? [],
      caseSensitive: options.caseSensitive ?? false,
      countNumbers: options.countNumbers ?? true,
      ...options
    };
  }

  /**
   * Count words in XML file (async)
   */
  async countWordsFromFile(filePath: string): Promise<WordCountResult> {
    try {
      const absolutePath = resolve(filePath);
      const xmlContent = await readFileAsync(absolutePath, 'utf-8');
      const result = this.countWordsFromString(xmlContent);
      result.filePath = absolutePath;
      return result;
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to read XML file '${filePath}': ${error.message}`);
      }
      throw error;
    }
  }

  /**
   * Count words in XML file (sync)
   */
  countWordsFromFileSync(filePath: string): WordCountResult {
    try {
      const absolutePath = resolve(filePath);
      const xmlContent = readFileSync(absolutePath, 'utf-8');
      const result = this.countWordsFromString(xmlContent);
      result.filePath = absolutePath;
      return result;
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to read XML file '${filePath}': ${error.message}`);
      }
      throw error;
    }
  }

  manageXmlParseError(msg: any, errorLevel: number, errorLog: { [x: string]: any[]; // @ts-ignore
    errorLevel: number | null; }){
    if( (errorLog.errorLevel == null) || (errorLog.errorLevel < errorLevel)){
      errorLog.errorLevel = errorLevel;
    }

    if(errorLog[errorLevel.toString()] == null){
      errorLog[errorLevel.toString()] = [];
    }

    errorLog[errorLevel.toString()].push(msg);
  }

  /**
   * Count words in XML string
   */
  countWordsFromString(xmlString: string): WordCountResult {
    const parser = new DOMParser({
      onError: onErrorStopParsing
    });

    const doc = parser.parseFromString(xmlString, 'text/xml');

    // Additional check for xmldom parsing errors
    if (!doc || !doc.documentElement) {
      throw new Error('Failed to parse XML document');
    }

    return this.countWordsFromDocument(doc);
  }

  /**
   * Count words in XML document
   */
  countWordsFromDocument(doc: Document): WordCountResult {
    const wordFrequency = new Map<string, number>();
    const elementWordCounts = new Map<string, number>();

    this.processNode(doc.documentElement, wordFrequency, elementWordCounts);

    return {
      totalWords: Array.from(wordFrequency.values()).reduce((sum, count) => sum + count, 0),
      uniqueWords: wordFrequency.size,
      wordFrequency,
      elementWordCounts
    };
  }

  /**
   * Process multiple XML files and return combined results
   */
  async countWordsFromMultipleFiles(filePaths: string[]): Promise<{
    individual: WordCountResult[];
    combined: WordCountResult;
  }> {
    const individual = await Promise.all(
      filePaths.map(filePath => this.countWordsFromFile(filePath))
    );

    // Combine results
    const combinedWordFreq = new Map<string, number>();
    const combinedElementCounts = new Map<string, number>();

    individual.forEach(result => {
      // Merge word frequencies
      result.wordFrequency.forEach((count, word) => {
        combinedWordFreq.set(word, (combinedWordFreq.get(word) || 0) + count);
      });

      // Merge element counts
      result.elementWordCounts.forEach((count, element) => {
        combinedElementCounts.set(element, (combinedElementCounts.get(element) || 0) + count);
      });
    });

    const combined: WordCountResult = {
      totalWords: Array.from(combinedWordFreq.values()).reduce((sum, count) => sum + count, 0),
      uniqueWords: combinedWordFreq.size,
      wordFrequency: combinedWordFreq,
      elementWordCounts: combinedElementCounts,
      filePath: `Combined from ${filePaths.length} files`
    };

    return { individual, combined };
  }

  /**
   * Process a DOM node recursively
   */
  private processNode(
    node: Node,
    wordFrequency: Map<string, number>,
    elementWordCounts: Map<string, number>
  ): void {
    // xmldom Node types
    const ELEMENT_NODE = 1;
    const TEXT_NODE = 3;

    if (node.nodeType === ELEMENT_NODE) {
      const element = node as Element;
      const tagName = element.tagName.toLowerCase();

      // Skip excluded elements
      if (this.options.excludeElements.includes(tagName)) {
        return;
      }

      // Process attributes if enabled
      if (this.options.includeAttributes && element.attributes) {
        for (let i = 0; i < element.attributes.length; i++) {
          const attr = element.attributes.item(i);
          if (attr) {
            const words = this.extractWords(attr.value);
            this.addWordsToMaps(words, wordFrequency, elementWordCounts, `${tagName}@${attr.name}`);
          }
        }
      }

      // Process child nodes
      for (let i = 0; i < node.childNodes.length; i++) {
        const childNode = node.childNodes.item(i);
        if (childNode) {
          this.processNode(childNode, wordFrequency, elementWordCounts);
        }
      }
    } else if (node.nodeType === TEXT_NODE) {
      const textContent = node.nodeValue?.trim();
      if (textContent) {
        const words = this.extractWords(textContent);
        const parentElement = (node.parentNode as Element)?.tagName?.toLowerCase() || 'text';
        this.addWordsToMaps(words, wordFrequency, elementWordCounts, parentElement);
      }
    }
  }

  /**
   * Extract words from text using comprehensive regex
   */
  private extractWords(text: string): string[] {
    if (!text) return [];

    // Handle different word patterns
    let wordPattern: RegExp;

    if (this.options.countNumbers) {
      // Include numbers and words with numbers
      wordPattern = /\b[\w''-]+\b/g;
    } else {
      // Only alphabetic words (including apostrophes and hyphens)
      wordPattern = /\b[a-zA-Z]+(?:[''-][a-zA-Z]+)*\b/g;
    }

    const matches = text.match(wordPattern) || [];

    return matches
      .filter(word => word.length > 0)
      .map(word => {
        // Clean up the word
        word = word.replace(/^[''-]+|[''-]+$/g, ''); // Remove leading/trailing punctuation
        return this.options.caseSensitive ? word : word.toLowerCase();
      })
      .filter(word => word.length > 0);
  }

  /**
   * Add words to frequency and element count maps
   */
  private addWordsToMaps(
    words: string[],
    wordFrequency: Map<string, number>,
    elementWordCounts: Map<string, number>,
    elementName: string
  ): void {
    words.forEach(word => {
      // Update word frequency
      wordFrequency.set(word, (wordFrequency.get(word) || 0) + 1);

      // Update element word count
      elementWordCounts.set(elementName, (elementWordCounts.get(elementName) || 0) + 1);
    });
  }

  /**
   * Get detailed statistics
   */
  getDetailedStats(result: WordCountResult): {
    filePath?: string;
    totalWords: number;
    uniqueWords: number;
    averageWordLength: number;
    mostFrequentWords: Array<[string, number]>;
    elementBreakdown: Array<[string, number]>;
  } {
    const words = Array.from(result.wordFrequency.keys());
    const averageWordLength = words.reduce((sum, word) => sum + word.length, 0) / words.length || 0;

    const mostFrequentWords = Array.from(result.wordFrequency.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10);

    const elementBreakdown = Array.from(result.elementWordCounts.entries())
      .sort((a, b) => b[1] - a[1]);

    return {
      filePath: result.filePath,
      totalWords: result.totalWords,
      uniqueWords: result.uniqueWords,
      averageWordLength: Math.round(averageWordLength * 100) / 100,
      mostFrequentWords,
      elementBreakdown
    };
  }

  /**
   * Export results to JSON file
   */
  async exportResults(result: WordCountResult, outputPath: string): Promise<void> {
    const stats = this.getDetailedStats(result);
    const exportData = {
      ...stats,
      wordFrequency: Object.fromEntries(result.wordFrequency),
      elementWordCounts: Object.fromEntries(result.elementWordCounts),
      timestamp: new Date().toISOString()
    };

    const { writeFile } = await import('fs');
    const writeFileAsync = promisify(writeFile);

    await writeFileAsync(outputPath, JSON.stringify(exportData, null, 2));
  }
}

// ===== INSTALLATION AND SETUP =====
/*
To use this XML Word Counter in Node.js, install the required dependencies:

npm install @xmldom/xmldom glob

Or add to your package.json:
{
  "dependencies": {
    "@xmldom/xmldom": "^0.8.10",
    "glob": "^10.3.10"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "typescript": "^5.0.0"
  }
}

Then compile and run:
npx tsc your-file.ts
node your-file.js
*/

// ===== SAMPLE USAGE EXAMPLES =====

// Example 1: Process single XML file (async)
async function processSingleFileAsync() {
  console.log('=== Single File Processing (Async) ===');

  const counter = new XMLWordCounter({
    includeAttributes: false,
    excludeElements: ['metadata', 'script', 'style'],
    caseSensitive: false,
    countNumbers: true
  });

  try {
    // Process a single XML file
    const result = await counter.countWordsFromFile('./sample-document.xml');
    const stats = counter.getDetailedStats(result);

    console.log(`File: ${stats.filePath}`);
    console.log(`Total words: ${stats.totalWords}`);
    console.log(`Unique words: ${stats.uniqueWords}`);
    console.log(`Average word length: ${stats.averageWordLength}`);

    console.log('\nTop 5 most frequent words:');
    stats.mostFrequentWords.slice(0, 5).forEach(([word, count]) => {
      console.log(`  "${word}": ${count} times`);
    });

    // Export results to JSON
    await counter.exportResults(result, './word-count-results.json');
    console.log('\n✓ Results exported to word-count-results.json');

  } catch (error) {
    if (error instanceof Error) {
      console.error('Error processing file:', error.message);
    }
  }
}

// Example 2: Process single XML file (sync)
function processSingleFileSync() {
  console.log('\n=== Single File Processing (Sync) ===');

  const counter = new XMLWordCounter({
    includeAttributes: true,
    caseSensitive: false,
    countNumbers: true
  });

  try {
    const result = counter.countWordsFromFileSync('./test.xml');
    const stats = counter.getDetailedStats(result);

    console.log(`File: ${stats.filePath}`);
    console.log(`Total words: ${stats.totalWords}`);
    console.log(`Unique words: ${stats.uniqueWords}`);

    console.log('\nElement breakdown:');
    stats.elementBreakdown.slice(0, 5).forEach(([element, count]) => {
      console.log(`  <${element}>: ${count} words`);
    });

  } catch (error) {
    if (error instanceof Error) {
      console.error('Error processing file:', error.message);
    }
  }
}

// Example 3: Process multiple XML files
async function processMultipleFiles() {
  console.log('\n=== Multiple File Processing ===');

  const counter = new XMLWordCounter({
    includeAttributes: false,
    excludeElements: ['metadata', 'header', 'footer'],
    caseSensitive: false,
    countNumbers: true
  });

  const filePaths = [
    './documents/chapter1.xml',
    './documents/chapter2.xml',
    './documents/chapter3.xml'
  ];

  try {
    const { individual, combined } = await counter.countWordsFromMultipleFiles(filePaths);

    console.log('Individual file results:');
    individual.forEach((result, index) => {
      const stats = counter.getDetailedStats(result);
      console.log(`  ${filePaths[index]}: ${stats.totalWords} words, ${stats.uniqueWords} unique`);
    });

    const combinedStats = counter.getDetailedStats(combined);
    console.log(`\nCombined results:`);
    console.log(`  Total words across all files: ${combinedStats.totalWords}`);
    console.log(`  Total unique words: ${combinedStats.uniqueWords}`);
    console.log(`  Average word length: ${combinedStats.averageWordLength}`);

    console.log('\nMost frequent words across all files:');
    combinedStats.mostFrequentWords.slice(0, 8).forEach(([word, count]) => {
      console.log(`  "${word}": ${count} occurrences`);
    });

  } catch (error) {
    if (error instanceof Error) {
      console.error('Error processing multiple files:', error.message);
    }
  }
}

// Example 4: Directory processing with glob pattern
async function processDirectory() {
  console.log('\n=== Directory Processing ===');

  const { glob } = await import('glob');
  const xmlFiles = await glob('./documents/**/*.xml');

  if (xmlFiles.length === 0) {
    console.log('No XML files found in ./documents/');
    return;
  }

  const counter = new XMLWordCounter({
    includeAttributes: false,
    excludeElements: ['script', 'style', 'metadata'],
    caseSensitive: false,
    countNumbers: true
  });

  try {
    console.log(`Found ${xmlFiles.length} XML files:`);
    xmlFiles.forEach(file => console.log(`  - ${file}`));

    const { individual, combined } = await counter.countWordsFromMultipleFiles(xmlFiles);

    // Sort files by word count
    const sortedResults = individual
      .map((result, index) => ({ result, filePath: xmlFiles[index] }))
      .sort((a, b) => b.result.totalWords - a.result.totalWords);

    console.log('\nFiles ranked by word count:');
    sortedResults.forEach(({ result, filePath }, index) => {
      const stats = counter.getDetailedStats(result);
      console.log(`  ${index + 1}. ${filePath}: ${stats.totalWords} words`);
    });

    const combinedStats = counter.getDetailedStats(combined);
    console.log(`\nDirectory totals:`);
    console.log(`  Files processed: ${xmlFiles.length}`);
    console.log(`  Total words: ${combinedStats.totalWords.toLocaleString()}`);
    console.log(`  Unique vocabulary: ${combinedStats.uniqueWords.toLocaleString()}`);

  } catch (error) {
    if (error instanceof Error) {
      console.error('Error processing directory:', error.message);
    }
  }
}

// Example 5: Large file processing with progress
async function processLargeFile() {
  console.log('\n=== Large File Processing ===');

  const counter = new XMLWordCounter({
    includeAttributes: false,
    excludeElements: ['metadata'],
    caseSensitive: false,
    countNumbers: true
  });

  const filePath = './large-document.xml';

  try {
    console.log(`Processing large file: ${filePath}`);
    console.log('Reading file...');

    const startTime = Date.now();
    const result = await counter.countWordsFromFile(filePath);
    const endTime = Date.now();

    const stats = counter.getDetailedStats(result);

    console.log(`\n✓ Processing completed in ${endTime - startTime}ms`);
    console.log(`File size: ${(await import('fs')).statSync(filePath).size} bytes`);
    console.log(`Total words: ${stats.totalWords.toLocaleString()}`);
    console.log(`Unique words: ${stats.uniqueWords.toLocaleString()}`);
    console.log(`Processing speed: ${Math.round(stats.totalWords / ((endTime - startTime) / 1000)).toLocaleString()} words/second`);

  } catch (error) {
    if (error instanceof Error) {
      console.error('Error processing large file:', error.message);
    }
  }
}

// Example 6: Comparison across different configurations
async function compareConfigurations() {
  console.log('\n=== Configuration Comparison ===');

  const filePath = './sample-document.xml';

  const configs = [
    { name: 'Content Only', options: { includeAttributes: false, countNumbers: false } },
    { name: 'Content + Numbers', options: { includeAttributes: false, countNumbers: true } },
    { name: 'Content + Attributes', options: { includeAttributes: true, countNumbers: false } },
    { name: 'Everything', options: { includeAttributes: true, countNumbers: true } },
    { name: 'Exclude Metadata', options: { includeAttributes: true, countNumbers: true, excludeElements: ['metadata', 'header'] } }
  ];

  try {
    console.log(`Comparing configurations on: ${filePath}\n`);

    for (const config of configs) {
      const counter = new XMLWordCounter(config.options);
      const result = await counter.countWordsFromFile(filePath);
      const stats = counter.getDetailedStats(result);

      console.log(`${config.name}:`);
      console.log(`  Total words: ${stats.totalWords}`);
      console.log(`  Unique words: ${stats.uniqueWords}`);
      console.log(`  Vocabulary ratio: ${(stats.uniqueWords / stats.totalWords * 100).toFixed(1)}%`);
      console.log();
    }

  } catch (error) {
    if (error instanceof Error) {
      console.error('Error in configuration comparison:', error.message);
    }
  }
}

// ===== UTILITY FUNCTIONS =====


// ===== MAIN EXECUTION =====
async function runAllExamples() {

   await processDirectory();
}

export {XMLWordCounter};
export type { WordCountOptions, WordCountResult };

// Uncomment to run examples:
 runAllExamples().catch(console.error);
