// eCFR API Types
export interface TitleCount {
    title: number;
    count: number;
}

export interface TitlesCountResponse {
    counts: TitleCount[];
}

export interface EcfrApiConfig {
    timeout?: number;
    headers?: Record<string, string>;
}

// Custom error class for eCFR API
export class EcfrApiError extends Error {
    public readonly status: number;
    public readonly statusText: string;

    constructor(message: string, status: number, statusText: string) {
        super(message);
        this.name = 'EcfrApiError';
        this.status = status;
        this.statusText = statusText;
    }
}

// eCFR API Client
export class EcfrApi {
    private readonly baseUrl: string = 'https://www.ecfr.gov';
    private readonly defaultHeaders: Record<string, string>;
    private readonly timeout: number;

    constructor(config: EcfrApiConfig = {}) {
        this.timeout = config.timeout || 10000;
        this.defaultHeaders = {
            'accept': 'application/json',
            ...config.headers,
        };
    }

    /**
     * Get title counts from the eCFR API
     * @returns Promise<TitlesCountResponse>
     * @throws {EcfrApiError} When the API request fails
     */
    async getTitlesCounts(): Promise<TitlesCountResponse> {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), this.timeout);

            const response = await fetch(`${this.baseUrl}/api/search/v1/counts/titles`, {
                method: 'GET',
                headers: this.defaultHeaders,
                signal: controller.signal,
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new EcfrApiError(
                    `Failed to fetch title counts: ${response.statusText}`,
                    response.status,
                    response.statusText
                );
            }

            const data = await response.json();
            return this.validateTitlesCountResponse(data);
        } catch (error) {
            if (error instanceof EcfrApiError) {
                throw error;
            }

            if (error instanceof Error) {
                if (error.name === 'AbortError') {
                    throw new EcfrApiError('Request timeout', 408, 'Request Timeout');
                }
                throw new EcfrApiError(error.message, 0, 'Network Error');
            }

            throw new EcfrApiError('Unknown error occurred', 0, 'Unknown Error');
        }
    }

    /**
     * Validate the API response structure
     * @private
     */
    private validateTitlesCountResponse(data: any): TitlesCountResponse {
        if (!data || typeof data !== 'object') {
            throw new EcfrApiError('Invalid response format', 0, 'Invalid Response');
        }

        if (!Array.isArray(data.counts)) {
            throw new EcfrApiError('Response missing counts array', 0, 'Invalid Response');
        }

        // Validate each count object
        for (const count of data.counts) {
            if (!this.isValidTitleCount(count)) {
                throw new EcfrApiError('Invalid title count object in response', 0, 'Invalid Response');
            }
        }

        return data as TitlesCountResponse;
    }

    /**
     * Validate a single title count object
     * @private
     */
    private isValidTitleCount(count: any): count is TitleCount {
        return (
            count &&
            typeof count === 'object' &&
            typeof count.title === 'number' &&
            typeof count.count === 'number'
        );
    }
}

// Factory function for easy import
export const createEcfrApi = (config?: EcfrApiConfig): EcfrApi => {
    return new EcfrApi(config);
};