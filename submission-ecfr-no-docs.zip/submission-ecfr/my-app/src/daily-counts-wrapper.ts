// eCFR Daily Counts API TypeScript Wrapper

const BASE_URL = 'https://www.ecfr.gov';

// Type definitions
export interface DailyCountsResponse {
    dates: Record<string, number>;
}

export interface DailyCountsOptions {
    query?: string;
    agency_slugs?: string[];
}

// Error handling
export class ECFRApiError extends Error {
    constructor(
        message: string,
        public status?: number,
        public response?: any
    ) {
        super(message);
        this.name = 'ECFRApiError';
    }
}

// Helper function to build query parameters
function buildQueryParams(options: DailyCountsOptions): string {
    const params = new URLSearchParams();

    if (options.query) {
        params.append('query', options.query);
    }

    if (options.agency_slugs && options.agency_slugs.length > 0) {
        options.agency_slugs.forEach(slug => {
            params.append('agency_slugs[]', slug);
        });
    }

    const queryString = params.toString();
    return queryString ? `?${queryString}` : '';
}

/**
 * Fetches daily counts from the eCFR API
 * @param options - Optional parameters for filtering the results
 * @returns Promise<DailyCountsResponse> - Object with dates as keys and counts as values
 * @throws ECFRApiError - When the API request fails
 */
export async function getDailyCounts(options: DailyCountsOptions = {}): Promise<DailyCountsResponse> {
    const queryParams = buildQueryParams(options);
    const url = `${BASE_URL}/api/search/v1/counts/daily${queryParams}`;

    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new ECFRApiError(
                `Failed to fetch daily counts: ${response.status} ${response.statusText}`,
                response.status,
                await response.text().catch(() => null)
            );
        }

        const data: DailyCountsResponse = await response.json();
        return data;
    } catch (error) {
        if (error instanceof ECFRApiError) {
            throw error;
        }
        throw new ECFRApiError(
            `Network error while fetching daily counts: ${error instanceof Error ? error.message : 'Unknown error'}`
        );
    }
}