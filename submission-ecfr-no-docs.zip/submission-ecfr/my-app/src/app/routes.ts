import {Routes} from '@angular/router';
import {Agency} from './agency/agency';
import {AgencyDetails} from './agency-details/agency-details';

const routeConfig: Routes = [
  {
    path: '',
    component: Agency,
    title: 'Home page',
  },
  {
    path: 'details/:id',
    component: AgencyDetails,
    title: 'Home details',
  }
];
export default routeConfig;
