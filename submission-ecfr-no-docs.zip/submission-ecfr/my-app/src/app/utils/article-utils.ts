/**
 * TypeScript interfaces and wrapper for regulation search results
 */

// Base hierarchy structure
export interface Hierarchy {
  title: string;
  subtitle: string;
  chapter: string;
  subchapter: string;
  part: string;
  subpart: string;
  subject_group: string | null;
  section: string;
  appendix: string | null;
}

// Hierarchy headings with formatted display names
export interface HierarchyHeadings {
  title: string;
  subtitle: string;
  chapter: string;
  subchapter: string;
  part: string;
  subpart: string;
  subject_group: string | null;
  section: string;
  appendix: string | null;
}

// Human-readable headings for each hierarchy level
export interface Headings {
  title: string;
  subtitle: string;
  chapter: string;
  subchapter: string;
  part: string;
  subpart: string;
  subject_group: string | null;
  section: string;
  appendix: string | null;
}

// Change types enumeration
export type ChangeType = "effective" | "initial" | "amended" | "removed" | "reserved";

// Main regulation result interface
export interface RegulationResult {
  starts_on: string;
  ends_on: string;
  type: string;
  hierarchy: Hierarchy;
  hierarchy_headings: HierarchyHeadings;
  headings: Headings;
  full_text_excerpt: string;
  score: number;
  structure_index: number;
  reserved: boolean;
  removed: boolean;
  change_types: ChangeType[];
  sentiment_analysis: string;
}

// Root response interface
export interface RegulationSearchResponse {
  results: RegulationResult[];
}

/**
 * Call signatures for all wrapper methods
 */
export interface RegulationSearchWrapperInterface {
  getAllResults(): RegulationResult[];
  getResultsByType(type: string): RegulationResult[];
  getResultsByMinScore(minScore: number): RegulationResult[];
  getResultsByDateRange(startDate: string, endDate: string): RegulationResult[];
  getResultsByHierarchyLevel(level: keyof Hierarchy, value: string): RegulationResult[];
  getActiveResults(): RegulationResult[];
  getResultsSortedByScore(): RegulationResult[];
  getUniqueChangeTypes(): ChangeType[];
  getHierarchyPath(result: RegulationResult): string;
  getDisplayName(result: RegulationResult): string;
  getSummaryStats(): {
    totalResults: number;
    averageScore: number;
    dateRange: { earliest: string; latest: string };
    typeDistribution: Record<string, number>;
  };
  // Extended methods
  filterResults(predicate: FilterPredicateSignature<RegulationResult>): RegulationResult[];
  sortResults(comparator: SortComparatorSignature<RegulationResult>): RegulationResult[];
  mapResults<T>(mapper: MapperSignature<RegulationResult, T>): T[];
  findResult(predicate: FilterPredicateSignature<RegulationResult>): RegulationResult | undefined;
  groupResultsBy<K extends string | number | symbol>(
    keySelector: MapperSignature<RegulationResult, K>
  ): Record<K, RegulationResult[]>;
}

/**
 * Call signatures for utility functions
 */
export type CreateRegulationWrapperSignature = (jsonData: any) => RegulationSearchWrapper;
export type IsRegulationSearchResponseSignature = (obj: any) => obj is RegulationSearchResponse;


/**
 * Wrapper class for handling regulation search results
 */
export class RegulationSearchWrapper implements RegulationSearchWrapperInterface {
  private data: RegulationSearchResponse;

  constructor(jsonData: RegulationSearchResponse) {
    this.data = jsonData;
  }

  /**
   * Get all results
   */
  getAllResults(): RegulationResult[] {
    return this.data.results;
  }

  /**
   * Get results filtered by type
   */
  getResultsByType(type: string): RegulationResult[] {
    return this.data.results.filter(result => result.type === type);
  }

  /**
   * Get results filtered by score threshold
   */
  getResultsByMinScore(minScore: number): RegulationResult[] {
    return this.data.results.filter(result => result.score >= minScore);
  }

  /**
   * Get results filtered by date range
   */
  getResultsByDateRange(startDate: string, endDate: string): RegulationResult[] {
    return this.data.results.filter(result => {
      const resultStart = new Date(result.starts_on);
      const resultEnd = new Date(result.ends_on);
      const filterStart = new Date(startDate);
      const filterEnd = new Date(endDate);

      return resultStart >= filterStart && resultEnd <= filterEnd;
    });
  }

  /**
   * Get results by specific hierarchy level
   */
  getResultsByHierarchyLevel(level: keyof Hierarchy, value: string): RegulationResult[] {
    return this.data.results.filter(result => result.hierarchy[level] === value);
  }

  /**
   * Get active results (not removed or reserved)
   */
  getActiveResults(): RegulationResult[] {
    return this.data.results.filter(result => !result.removed && !result.reserved);
  }

  /**
   * Get results sorted by score (descending)
   */
  getResultsSortedByScore(): RegulationResult[] {
    return [...this.data.results].sort((a, b) => b.score - a.score);
  }

  /**
   * Get unique change types across all results
   */
  getUniqueChangeTypes(): ChangeType[] {
    const changeTypes = this.data.results
      .flatMap(result => result.change_types)
      .filter((type, index, array) => array.indexOf(type) === index);

    return changeTypes as ChangeType[];
  }

  /**
   * Get regulation hierarchy path as string
   */
  getHierarchyPath(result: RegulationResult): string {
    const hierarchy = result.hierarchy;
    const parts = [
      hierarchy.title,
      hierarchy.subtitle,
      hierarchy.chapter,
      hierarchy.subchapter,
      hierarchy.part,
      hierarchy.subpart,
      hierarchy.section
    ].filter(part => part && part !== 'null');

    return parts.join(' > ');
  }

  /**
   * Get formatted display name for a result
   */
  getDisplayName(result: RegulationResult): string {
    const headings = result.hierarchy_headings;
    return `${headings.section} - ${result.headings.section}`;
  }

  /**
   * Generic filter method with custom predicate
   */
  filterResults(predicate: FilterPredicateSignature<RegulationResult>): RegulationResult[] {
    return this.data.results.filter(predicate);
  }

  /**
   * Generic sort method with custom comparator
   */
  sortResults(comparator: SortComparatorSignature<RegulationResult>): RegulationResult[] {
    return [...this.data.results].sort(comparator);
  }

  /**
   * Generic map method for transforming results
   */
  mapResults<T>(mapper: MapperSignature<RegulationResult, T>): T[] {
    return this.data.results.map(mapper);
  }

  /**
   * Find first result matching predicate
   */
  findResult(predicate: FilterPredicateSignature<RegulationResult>): RegulationResult | undefined {
    return this.data.results.find(predicate);
  }

  /**
   * Group results by a specified key
   */
  groupResultsBy<K extends string | number | symbol>(
    keySelector: MapperSignature<RegulationResult, K>
  ): Record<K, RegulationResult[]> {
    return this.data.results.reduce((groups, result) => {
      const key = keySelector(result);
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(result);
      return groups;
    }, {} as Record<K, RegulationResult[]>);
  }
  getSummaryStats(): {
    totalResults: number;
    averageScore: number;
    dateRange: { earliest: string; latest: string };
    typeDistribution: Record<string, number>;
  } {
    const results = this.data.results;

    const totalResults = results.length;
    const averageScore = results.reduce((sum, r) => sum + r.score, 0) / totalResults;

    const dates = results.flatMap(r => [r.starts_on, r.ends_on]).sort();
    const dateRange = {
      earliest: dates[0],
      latest: dates[dates.length - 1]
    };

    const typeDistribution = results.reduce((acc, result) => {
      acc[result.type] = (acc[result.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalResults,
      averageScore: Math.round(averageScore * 100) / 100,
      dateRange,
      typeDistribution
    };
  }
}

// Example usage
export const createRegulationWrapper: CreateRegulationWrapperSignature = (jsonData: any): RegulationSearchWrapper => {
  return new RegulationSearchWrapper(jsonData as RegulationSearchResponse);
};

// Type guard function
export const isRegulationSearchResponse: IsRegulationSearchResponseSignature = (obj: any): obj is RegulationSearchResponse => {
  return (
    obj &&
    typeof obj === 'object' &&
    Array.isArray(obj.results) &&
    obj.results.every((result: any) =>
      typeof result === 'object' &&
      typeof result.starts_on === 'string' &&
      typeof result.ends_on === 'string' &&
      typeof result.type === 'string' &&
      typeof result.hierarchy === 'object' &&
      typeof result.score === 'number'
    )
  );
};

/**
 * Additional call signatures for custom filtering and processing
 */
export type FilterPredicateSignature<T> = (item: T) => boolean;
export type SortComparatorSignature<T> = (a: T, b: T) => number;
export type MapperSignature<T, U> = (item: T) => U;

/**
 * Extended wrapper interface with additional method signatures
 */
export interface ExtendedRegulationSearchWrapperInterface extends RegulationSearchWrapperInterface {
  filterResults(predicate: FilterPredicateSignature<RegulationResult>): RegulationResult[];
  sortResults(comparator: SortComparatorSignature<RegulationResult>): RegulationResult[];
  mapResults<T>(mapper: MapperSignature<RegulationResult, T>): T[];
  findResult(predicate: FilterPredicateSignature<RegulationResult>): RegulationResult | undefined;
  groupResultsBy<K extends string | number | symbol>(
    keySelector: MapperSignature<RegulationResult, K>
  ): Record<K, RegulationResult[]>;
}
