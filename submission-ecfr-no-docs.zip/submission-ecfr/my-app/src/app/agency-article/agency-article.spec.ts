import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyArticle } from './agency-article';

describe('AgencyArticle', () => {
  let component: AgencyArticle;
  let fixture: ComponentFixture<AgencyArticle>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AgencyArticle]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgencyArticle);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
