import {Component, Input, signal} from '@angular/core';
import {RegulationResult} from '../utils/article-utils';
import {
  MatAccordion,
  MatExpansionPanel,
  MatExpansionPanelDescription, MatExpansionPanelHeader,
  MatExpansionPanelTitle
} from '@angular/material/expansion';

@Component({
  selector: 'app-agency-article',
  imports: [
    MatAccordion,
    MatExpansionPanel,
    MatExpansionPanelTitle,
    MatExpansionPanelDescription,
    MatExpansionPanelHeader
  ],
  templateUrl: './agency-article.html',
  styleUrl: './agency-article.css'
})
export class AgencyArticle {
  @Input() agencyInfoReal!: RegulationResult;

}
