import {Component, input} from '@angular/core';
import {AgencyInfo, AgencyInfoReal} from './agencyinfo';
import {RouterLink} from '@angular/router';

@Component({
  selector: 'app-agency-list',
  imports: [
    RouterLink
  ],
  templateUrl: './agency-list.html',
  styleUrl: './agency-list.css'
})
export class AgencyList {
  agencyInfoReal = input.required<AgencyInfoReal>();
}
