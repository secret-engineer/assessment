export interface AgencyInfo {
  id: number;
  name: string;
  city: string;
  state: string;
  availableUnits: number;
  wifi: boolean;
  laundry: boolean;
}

export interface AgencyInfoReal{
  name: string,
  short_name: string,
  display_name: string,
  sortable_name: string,
  slug: string,
  children: [],
  cfr_references:[]

}
