import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyDetails } from './agency-details';

describe('AgencyDetails', () => {
  let component: AgencyDetails;
  let fixture: ComponentFixture<AgencyDetails>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AgencyDetails]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgencyDetails);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
