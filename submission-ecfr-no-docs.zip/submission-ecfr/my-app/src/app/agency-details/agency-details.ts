import {Component, inject, Input} from '@angular/core';
import {ActivatedRoute, RouterLink} from '@angular/router';
import {AgencyService} from '../services/agency.service';
import {AgencyInfo, AgencyInfoReal} from '../agency-list/agencyinfo';
import {AgencyList} from '../agency-list/agency-list';
import {NgForOf} from '@angular/common';
import {AgencyArticle} from '../agency-article/agency-article';
import {AgenciesResponse, ECFRApiError} from '../../agencies-wrapper';
import Sentiment  from "sentiment";
import {createRegulationWrapper, RegulationResult} from '../utils/article-utils';
const BASE_URL = 'https://www.ecfr.gov';

@Component({
  selector: 'app-agency-details',
  imports: [
    AgencyList,
    NgForOf,
    AgencyArticle,
    RouterLink
  ],
  templateUrl: './agency-details.html',
  styleUrl: './agency-details.css'
})
export class AgencyDetails {
  route: ActivatedRoute = inject(ActivatedRoute);
  agencyService = inject(AgencyService);
  agencyInfo: AgencyInfoReal | undefined;
  agencyListReal: string[] = [];
  filteredAgencyList: RegulationResult[] = [];
  @Input() agencyInfoReal!: string;

  constructor() {

    const housingLocationId = this.route.snapshot.params['id'];
    this.agencyService.getAgencyByIdReal(housingLocationId).then((agencyInfo) => {
      this.agencyInfo = agencyInfo;
    });
  }


  async findArticles(text: string, slug: string) {

    const params = new URLSearchParams();
    params.append("query", text+'*');
    params.append("agency_slugs[]", slug);
    const url = `${BASE_URL}/api/search/v1/results?${params}`;
    console.log('url', url);
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'accept': 'application/json'
        }
      });

      if (!response.ok) {
        throw new ECFRApiError(
          `Failed to fetch agencies: ${response.status} ${response.statusText}`,
          response.status,
          await response.text().catch(() => null)
        );
      }

     // const data: RegulationResult =

      const wrapper = createRegulationWrapper(await response.json());
      // https://www.ecfr.gov/api/search/v1/results?query=farm&agency_slugs%5B%5D=agriculture-department&per_page=20&page=1&order=relevance&paginate_by=results
      wrapper.getAllResults().forEach((result) => {
        result.sentiment_analysis = this.getSimpleTone(result.full_text_excerpt);
      })
      this.filteredAgencyList = wrapper.getAllResults();
      console.log('data', wrapper);

      console.log(this.getSimpleTone("must have records on what land is being <strong>farmed</strong> by a particular producer. This is accomplished<span class=\"elipsis\">…</span>lands “constitute” an individual unit or <strong>farm</strong>. Land that was properly constituted under<span class=\"elipsis\">…</span>land as a “<strong>farm</strong>” for the first time and the subsequent reconstitution of a <strong>farm</strong> made thereafter"));
      return "47";
    } finally {
    }
  }

  /**
   * Analyzes the sentiment/tone of the provided text
   * @param text - The text to analyze
   * @returns A string describing the sentiment analysis
   */
  analyzeSentiment(text: string): string {
    if (!text || text.trim().length === 0) {
      return "No text provided for analysis.";
    }

    const sentiment = new Sentiment();
    const result = sentiment.analyze(text);

    // Determine tone based on score
    let tone: string;
    if (result.score > 2) {
      tone = "Very Positive";
    } else if (result.score > 0) {
      tone = "Positive";
    } else if (result.score === 0) {
      tone = "Neutral";
    } else if (result.score > -2) {
      tone = "Negative";
    } else {
      tone = "Very Negative";
    }

    // Create detailed analysis string
    const analysis = `
Sentiment Analysis Results:
- Overall Tone: ${tone}
- Sentiment Score: ${result.score}
- Comparative Score: ${result.comparative.toFixed(3)}
- Total Words: ${result.tokens.length}
- Positive Words: ${result.positive.length > 0 ? result.positive.join(', ') : 'None'}
- Negative Words: ${result.negative.length > 0 ? result.negative.join(', ') : 'None'}
  `.trim();

    return analysis;
  }

/** Example usage
  const
  exampleText = "I love this amazing product! It works perfectly and exceeded my expectations.";
  console
.

  log(analyzeSentiment

(
  exampleText
));
*/
// Additional helper function for simple tone classification
  getSimpleTone(text: string): string {
    if (!text || text.trim().length === 0) {
      return "Neutral";
    }

    const sentiment = new Sentiment();
    const result = sentiment.analyze(text);

    if (result.score > 0) {
      return "Positive";
    } else if (result.score < 0) {
      return "Negative";
    } else {
      return "Neutral";
    }
  }
}


