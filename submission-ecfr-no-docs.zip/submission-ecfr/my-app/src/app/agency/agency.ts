import {Component, inject} from '@angular/core';
import {AgencyList} from '../agency-list/agency-list';
import {AgencyInfo, AgencyInfoReal} from '../agency-list/agencyinfo';
import {AgencyService} from '../services/agency.service';
import {CommonModule} from '@angular/common';

@Component({
  selector: 'app-agency',
  imports: [
    AgencyList, CommonModule
  ],
  templateUrl: './agency.html',
  styleUrl: './agency.css'
})
export class Agency {
  filteredAgencyList: AgencyInfoReal[] = [];
  agencyService: AgencyService = inject(AgencyService);
  agencyListReal: AgencyInfoReal[] = [];

  constructor() {

    this.agencyService.getAllAgenciesReal().then((housingLocationList: AgencyInfoReal[]) => {
      this.agencyListReal = housingLocationList;
      this.filteredAgencyList = this.agencyListReal;

    });

  }
  //
  filterResults(text: string) {
    if (!text) {
      this.filteredAgencyList = this.agencyListReal;
      return;
    }
    this.filteredAgencyList = this.agencyListReal.filter((housingLocation) =>
      housingLocation?.display_name.toLowerCase().includes(text.toLowerCase()),
    );
  }

}
