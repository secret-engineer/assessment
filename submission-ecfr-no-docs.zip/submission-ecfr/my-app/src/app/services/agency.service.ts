import { Injectable } from '@angular/core';
import { AgencyInfoReal} from '../agency-list/agencyinfo';

@Injectable({
  providedIn: 'root'
})
export class AgencyService {
  url = 'http://localhost:3000/locations';
  agencyUrl = 'http://localhost:3000/agencies';

  async getAllAgenciesReal(): Promise<AgencyInfoReal[]> {
    const data = await fetch(this.agencyUrl);
    return (await data.json()) ?? [];
  }

  async getAgencyByIdReal(id: number): Promise<AgencyInfoReal | undefined> {
    const data = await fetch(`${this.agencyUrl}?name=${id}`);
    const locationJson = await data.json();
    return locationJson[0] ?? {};
  }

  constructor() { }
}
