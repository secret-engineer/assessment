// eCFR Agencies API TypeScript Wrapper

const BASE_URL = 'https://www.ecfr.gov';

// Type definitions
export interface CFRReference {
    title: number;
    chapter: string;
}

export interface Agency {
    name: string;
    short_name: string;
    display_name: string;
    sortable_name: string;
    slug: string;
    children: Agency[];
    cfr_references: CFRReference[];
}

export interface AgenciesResponse {
    agencies: Agency[];
}

// Error handling
export class ECFRApiError extends Error {
    constructor(
        message: string,
        public status?: number,
        public response?: any
    ) {
        super(message);
        this.name = 'ECFRApiError';
    }
}

/**
 * Fetches all agencies from the eCFR API
 * @returns Promise<AgenciesResponse> - List of all agencies with their metadata
 * @throws ECFRApiError - When the API request fails
 */
export async function getAgencies(): Promise<AgenciesResponse> {
    const url = `${BASE_URL}/api/admin/v1/agencies.json`;

    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new ECFRApiError(
                `Failed to fetch agencies: ${response.status} ${response.statusText}`,
                response.status,
                await response.text().catch(() => null)
            );
        }

        const data: AgenciesResponse = await response.json();
        return data;
    } catch (error) {
        if (error instanceof ECFRApiError) {
            throw error;
        }
        throw new ECFRApiError(
            `Network error while fetching agencies: ${error instanceof Error ? error.message : 'Unknown error'}`
        );
    }
}